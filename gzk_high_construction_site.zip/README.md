# GZK High Construction - Site

Site React minimal (Vite) criado para GZK High Construction.

## Como rodar localmente

1. `npm install`
2. `npm run dev`
3. Abrir http://localhost:5173

## Deploy rápido (Vercel)
1. Crie uma conta em https://vercel.com
2. Faça push do repositório para o GitHub
3. No Vercel, clique em "New Project" e conecte o repositório
4. O Vercel detecta o projeto e faz o deploy automaticamente

--- 
Arquivos incluídos: App com rotas (Home, Serviços, Projetos, Imóveis, Contato) e logo.
