import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Services from './pages/Services'
import Projects from './pages/Projects'
import Contact from './pages/Contact'
import Properties from './pages/Properties'
import logo from './assets/logo.png'

export default function App(){
  return (
    <div>
      <header className="container header">
        <div className="logo">
          <img src={logo} alt="GZK Logo" />
          <div>
            <div style={{fontWeight:800}}>GZK High Construction</div>
            <small style={{color:'#6b7280'}}>Excelência em obras e projetos</small>
          </div>
        </div>
        <nav className="nav">
          <Link to="/">Home</Link>
          <Link to="/services">Serviços</Link>
          <Link to="/projects">Projetos</Link>
          <Link to="/properties">Imóveis</Link>
          <Link to="/contact">Contato</Link>
        </nav>
      </header>

      <main className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/properties" element={<Properties />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </main>

      <footer className="container footer">
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap'}}>
          <div>
            <strong>GZK High Construction</strong>
            <div>Rua Exemplo, 123 — Brasil</div>
          </div>
          <div>
            <div>Tel: (00) 00000-0000</div>
            <div>Email: contato@gzkconstruction.com</div>
          </div>
        </div>
      </footer>
    </div>
  )
}
