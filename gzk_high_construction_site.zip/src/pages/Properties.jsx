import React, {useState} from 'react'
const mock = [
  {id:1, type:'Residencial', title:'Casa 3 quartos - Bairro Nobre', price:'R$ 850.000'},
  {id:2, type:'Comercial', title:'Loja Centro Comercial', price:'R$ 1.200.000'},
  {id:3, type:'Industrial', title:'Galpão Logístico', price:'R$ 2.500.000'},
  {id:4, type:'Residencial', title:'Apartamento 2 quartos', price:'R$ 420.000'},
  {id:5, type:'Comercial', title:'Conjunto de salas comerciais', price:'R$ 980.000'},
]
export default function Properties(){
  const [filter, setFilter] = useState('Todos')
  const types = ['Todos','Residencial','Comercial','Industrial']
  const list = mock.filter(p=> filter==='Todos' ? true : p.type===filter)
  return (
    <div>
      <h1>Imóveis à Venda</h1>
      <div style={{marginTop:12, marginBottom:12}}>
        {types.map(t=>(
          <button key={t} onClick={()=>setFilter(t)} style={{marginRight:8, padding:'6px 10px', borderRadius:6, background: filter===t ? '#0f2740' : '#fff', color: filter===t ? '#fff' : '#0f2740', border:'1px solid #e6e6e6'}}>{t}</button>
        ))}
      </div>
      <div className="grid grid-cols-3">
        {list.map(p=>(
          <div className="card" key={p.id}>
            <h3>{p.title}</h3>
            <p style={{color:'#6b7280'}}>{p.type}</p>
            <strong>{p.price}</strong>
            <div style={{marginTop:8}}><button style={{padding:8, borderRadius:6, background:'#b68b2f', color:'#fff'}}>Ver Detalhes</button></div>
          </div>
        ))}
      </div>
    </div>
  )
}
