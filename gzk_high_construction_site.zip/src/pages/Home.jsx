import React from 'react'
export default function Home(){
  return (
    <div>
      <section className="hero">
        <h1 style={{fontSize:36, margin:0}}>Construindo com excelência e alto padrão</h1>
        <p style={{maxWidth:700, margin:'12px auto 0'}}>A GZK High Construction transforma projetos em realidade com qualidade, segurança e engenharia de ponta.</p>
      </section>

      <section style={{marginTop:20}}>
        <h2>Nossos Serviços</h2>
        <div className="grid grid-cols-3" style={{marginTop:12}}>
          <div className="card"><h3>Construção Residencial</h3><p>Casas modernas, seguras e de alto padrão.</p></div>
          <div className="card"><h3>Construção Comercial</h3><p>Projetos comerciais completos e funcionais.</p></div>
          <div className="card"><h3>Industrial</h3><p>Obras industriais com foco em logística e eficiência.</p></div>
        </div>
      </section>
    </div>
  )
}
