import React from 'react'
export default function Contact(){
  return (
    <div>
      <h1>Contato</h1>
      <p>Preencha o formulário ou entre em contato pelos dados abaixo.</p>
      <div style={{maxWidth:600, marginTop:12}}>
        <input placeholder="Seu nome" style={{width:'100%', padding:12, marginBottom:8}} />
        <input placeholder="Seu e-mail" style={{width:'100%', padding:12, marginBottom:8}} />
        <textarea placeholder="Mensagem" style={{width:'100%', padding:12, marginBottom:8}} rows={6} />
        <button style={{padding:12, background:'#0f2740', color:'white', borderRadius:8}}>Enviar</button>
      </div>
    </div>
  )
}
