import React from 'react'
export default function Projects(){
  return (
    <div>
      <h1>Projetos</h1>
      <p>Alguns projetos recentes da GZK.</p>
      <div className="grid grid-cols-3" style={{marginTop:12}}>
        {[1,2,3,4,5,6].map(n=>(
          <div className="card" key={n} style={{height:180, display:'flex', alignItems:'center', justifyContent:'center', fontSize:18}}>
            Projeto {n}
          </div>
        ))}
      </div>
    </div>
  )
}
