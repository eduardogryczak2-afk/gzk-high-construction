import React from 'react'
export default function Services(){
  const services = [
    {title:'Construção Residencial', desc:'Projetos de casas e condomínios.'},
    {title:'Construção Comercial', desc:'Lojas, escritórios, centros comerciais.'},
    {title:'Reformas e Ampliações', desc:'Renovações e ampliações com baixo impacto.'},
    {title:'Projetos e Gerenciamento', desc:'Gestão completa de obra e projetos.'},
    {title:'Industrial', desc:'Pavilhões e estruturas industriais.'},
  ]
  return (
    <div>
      <h1>Serviços</h1>
      <div className="grid grid-cols-3" style={{marginTop:12}}>
        {services.map((s,i)=>(
          <div className="card" key={i}>
            <h3>{s.title}</h3>
            <p style={{color:'#6b7280'}}>{s.desc}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
